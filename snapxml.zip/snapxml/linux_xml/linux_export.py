import os
import re
import subprocess

def list_files_and_snaphu_command(base_dir):
    # 获取 base_dir 下所有子文件夹
    subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]
    
    if not subdirs:
        print(f"No subdirectories found in {base_dir}")
        return

    # 按照修改时间排序，获取最新的子文件夹
    latest_subdir = max(subdirs, key=lambda d: os.path.getmtime(os.path.join(base_dir, d)))
    latest_subdir_path = os.path.join(base_dir, latest_subdir)

    print(f"Latest subdirectory: {latest_subdir_path}\n")
    
    # 列出最新子文件夹中的所有文件
    print("Files in the latest subdirectory:")
    for root, dirs, files in os.walk(latest_subdir_path):
        for file in files:
            print(f"- {file}")

    # 查找 snaphu.conf 文件并匹配命令
    snaphu_conf_path = os.path.join(latest_subdir_path, 'snaphu.conf')
    if os.path.isfile(snaphu_conf_path):
        print(f"\nLooking for snaphu command in {snaphu_conf_path}:\n")
        with open(snaphu_conf_path, 'r') as f:
            # 逐行读取文件并查找以 snaphu -f snaphu.conf 开头的行
            for line_num, line in enumerate(f, start=1):
                stripped_line = line.strip()  # 去掉行首和行尾的空白和换行符
                
                # 使用正则表达式匹配以 'snaphu -f snaphu.conf' 开头的命令
                match = re.match(r'#\s*(snaphu -f snaphu\.conf[^\n]*)', stripped_line)
                if match:
                    # 提取并打印匹配的命令
                    snaphu_command = match.group(1)
                    print(f"Found snaphu command: {snaphu_command}")

                    # 在 snaphu.conf 所在的目录下运行命令
                    snaphu_dir = os.path.dirname(snaphu_conf_path)
                    print(f"Changing directory to: {snaphu_dir}")
                    os.chdir(snaphu_dir)

                    try:
                        # 使用 subprocess.Popen 实时输出命令的结果
                        print(f"Executing snaphu command: {snaphu_command}")
                        process = subprocess.Popen(
                            snaphu_command, 
                            shell=True, 
                            stdout=subprocess.PIPE, 
                            stderr=subprocess.PIPE
                        )

                        # 实时输出标准输出和标准错误
                        for stdout_line in iter(process.stdout.readline, b''):
                            print(stdout_line.decode(), end='')  # 输出标准输出
                        for stderr_line in iter(process.stderr.readline, b''):
                            print(stderr_line.decode(), end='')  # 输出标准错误

                        process.stdout.close()
                        process.stderr.close()
                        process.wait()

                        # 检查命令是否执行成功
                        if process.returncode != 0:
                            print(f"Command failed with return code {process.returncode}")
                        else:
                            print("Command executed successfully.")
                        
                    except Exception as e:
                        print(f"Error executing command: {e}")
                    break
    else:
        print("\nNo snaphu.conf file found in the latest subdirectory.")

if __name__ == "__main__":
    # 设置目标文件夹路径
    base_dir = '/data/wangfengmao_file/Unwrapping'
    
    # 调用函数
    list_files_and_snaphu_command(base_dir)
